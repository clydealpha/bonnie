
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

// Ensure Chart.js is globally available
declare var Chart: any;

// --- INTERFACES ---
interface Capsule {
    id: string;
    tenant: string;
    version:string;
    status: 'Pending' | 'Executing' | 'Completed' | 'Failed' | 'Refused';
    executed_at: string;
    log_summary?: string;
    ipfs_hash?: string;
    ethereum_tx_id?: string;
    esgScore: number | null;
    refusalLog: string;
    esgQualitativeInsights?: string;
    financialDisclosures?: string;
    parameters?: Record<string, any>;
    metrics?: Record<string, any>;
}

interface User {
    name: string;
    email: string;
    role: 'Admin' | 'Developer' | 'Student';
    supabase_api_key_ref?: string;
    firebase_api_token_ref?: string;
    gemini_api_key_ref?: string; // This should be securely managed
    github_portfolio_link?: string;
    purpose_statement?: string;
}

interface AIChatMessage {
    role: 'user' | 'model' | 'system';
    message: string;
    timestamp?: string;
}

interface SmartManufacturingDecisionLogEntry {
    id: string;
    timestamp: string;
    type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR' | 'REFUSAL' | 'EXECUTION' | 'COMPLIANCE' | 'SYSTEM';
    message: string;
    capsuleId: string;
    details?: string;
}

interface SmartManufacturingPipelineStage {
    id: 'raw' | 'mfg' | 'qc' | 'pkg';
    name: string;
    status: 'Active' | 'Waiting' | 'Issue' | 'Paused';
    progress: number; // Percentage 0-100
    capsulesInStage: number;
}

interface SmartManufacturingData {
    statusText: 'ACTIVE' | 'MAINTENANCE' | 'OFFLINE';
    productionCapsules: number;
    esgCompliance: number; // Percentage
    autoRefusals: number;
    lastUpdated: string; // ISO string
    executionEngine: {
        status: 'ACTIVE' | 'PAUSED';
        executionCycles: number;
        currentCapsuleId: string;
        processingEfficiency: number; // Percentage
    };
    decisionLog: Array<SmartManufacturingDecisionLogEntry>;
    pipelineStages: {
        rawMaterialValidation: SmartManufacturingPipelineStage;
        smartManufacturing: SmartManufacturingPipelineStage;
        inlineQualityControl: SmartManufacturingPipelineStage;
        conditionalPackaging: SmartManufacturingPipelineStage;
    };
    productionMetrics: {
        tonsOutput: number;
        esgRate: number;
    };
    efficiencyMetrics: {
        avgDecisionTime: number; // seconds
        uptime: number; // percentage
    };
    qualityRefusals: {
        batchesToday: number;
        refusalRate: number; // percentage
    };
}

interface ApiKey {
    id: string;
    name: string;
    key: string; // Full secret key - only stored in memory temporarily after creation for display
    prefix: string; // e.g., "ca_sec_"
    preview: string; // e.g., "ca_sec_...xyz1"
    createdAt: string; // ISO Date string
    status: 'Active' | 'Revoked';
    scopes: string[]; // e.g., ["read:capsules", "execute:capsules"]
    lastUsed?: string; // ISO Date string, optional
}

interface ClydeAlphaApiEndpoint {
    method: 'GET' | 'POST' | 'PUT' | 'DELETE';
    path: string;
    description: string;
    parameters?: Array<{ name: string; type: string; description: string; required?: boolean }>;
    exampleRequest?: string; // JSON string or description
    exampleResponse?: string; // JSON string or description
}

interface AppConfig {
    CORE_API_BASE_URL: string;
    // Add other backend service URLs here
}

interface AppData {
    currentUser: User | null;
    capsules: Capsule[];
    selectedCapsuleIdMonitor: string | null;
    chat: Chat | null;
    chatHistory: AIChatMessage[];
    currentView: string;
    homePillarDetails: Record<string, { title: string, content: string, aiPrompt: string }>;
    homeStrategicTabsContent: Record<string, { title: string, content: string }>;
    smartManufacturingData: SmartManufacturingData;
    simulationIntervalId: number | null;
    apiKeys: ApiKey[];
    clydeAlphaApiEndpoints: ClydeAlphaApiEndpoint[];
    config: AppConfig;
}

interface DomElements {
    // General
    views: NodeListOf<HTMLElement>;
    navLinks: NodeListOf<HTMLElement>;
    mobileMenuButton: HTMLElement | null;
    mobileMenu: HTMLElement | null;
    toastNotification: HTMLElement | null;
    mainHeader: HTMLElement | null;
    homePageElements: NodeListOf<HTMLElement>;
    dashboardElements: NodeListOf<HTMLElement>;
    dashboardTitleHeader: HTMLElement | null;
    dashboardSubtitleHeader: HTMLElement | null;

    // Home View
    homeView: HTMLElement | null;
    homeExploreCapabilitiesBtn: HTMLElement | null;
    homeGenerateUsecaseBtn: HTMLElement | null;
    pillarItems: NodeListOf<HTMLElement>;
    pillarDetailTitle: HTMLElement | null;
    pillarDetailContent: HTMLElement | null;
    pillarAIExplanation: HTMLElement | null;
    pillarAIExplanationContent: HTMLElement | null;
    simplifyExplanationBtns: NodeListOf<HTMLButtonElement>;
    aiExplanationModal: HTMLElement | null;
    aiExplanationModalTitle: HTMLElement | null;
    aiExplanationModalContent: HTMLElement | null;
    closeAiExplanationModalBtn: HTMLElement | null;
    strategicValueTabs: NodeListOf<HTMLElement>;
    strategicValueContentPanes: NodeListOf<HTMLElement>;
    bonnie2LaunchButton: HTMLElement | null;
    simulatorLaunchDashboardBtn: HTMLElement | null;
    simulatorEnterControlDashboardBtn: HTMLElement | null;
    
    // Login View
    loginView: HTMLElement | null;
    emailInput: HTMLInputElement | null;
    passwordInput: HTMLInputElement | null;
    roleSelect: HTMLSelectElement | null;
    loginButton: HTMLElement | null;
    signupButton: HTMLElement | null;

    // Dashboard View
    dashboardView: HTMLElement | null;
    dashboardTabs: NodeListOf<HTMLElement>;
    dashboardTabPanesContainer: HTMLElement | null; // Parent of tab panes
    dashboardCapsuleTable: HTMLElement | null;
    // ... other dashboard tab elements (Supabase, Firebase, Vercel, JSON Loader)

    // Smart Manufacturing View
    smartManufacturingView: HTMLElement | null;
    smLastUpdated: HTMLElement | null;
    smStatusIcon: HTMLElement | null;
    smStatusText: HTMLElement | null;
    smProdCapsules: HTMLElement | null;
    smEsgCompliance: HTMLElement | null;
    smAutoRefusals: HTMLElement | null;
    smEngineStatus: HTMLElement | null;
    smExecCycles: HTMLElement | null;
    smCurrentCapsule: HTMLElement | null;
    smProcEfficiencyValue: HTMLElement | null;
    smProcEfficiencyBar: HTMLElement | null;
    smPauseExecutionBtn: HTMLElement | null;
    smPauseBtnIcon: SVGElement | null;
    smPauseBtnText: HTMLElement | null;
    smDecisionLog: HTMLElement | null;
    smPipelineTabs: NodeListOf<HTMLElement>;
    smPipelineTabContentPanes: NodeListOf<HTMLElement>;
    smCapsuleInspectorContent: HTMLElement | null;
    smFloatingChatBtn: HTMLElement | null;
    // Pipeline stage elements
    smPipelineRawStatus: HTMLElement | null; smPipelineRawProgress: HTMLElement | null; smPipelineRawProgressVal: HTMLElement | null; smPipelineRawCapsules: HTMLElement | null;
    smPipelineMfgStatus: HTMLElement | null; smPipelineMfgProgress: HTMLElement | null; smPipelineMfgProgressVal: HTMLElement | null; smPipelineMfgCapsules: HTMLElement | null;
    smPipelineQcStatus: HTMLElement | null; smPipelineQcProgress: HTMLElement | null; smPipelineQcProgressVal: HTMLElement | null; smPipelineQcCapsules: HTMLElement | null;
    smPipelinePkgStatus: HTMLElement | null; smPipelinePkgProgress: HTMLElement | null; smPipelinePkgProgressVal: HTMLElement | null; smPipelinePkgCapsules: HTMLElement | null;
    // Bottom metrics
    smProdMetricsTons: HTMLElement | null; smProdMetricsEsgRate: HTMLElement | null;
    smEfficiencyTime: HTMLElement | null; smEfficiencyUptime: HTMLElement |null;
    smQualityRefusalsBatches: HTMLElement | null; smQualityRefusalsRate: HTMLElement | null;


    // Capsule Uploader View
    capsuleUploaderView: HTMLElement | null;
    capsuleFileInput: HTMLInputElement | null;
    browseFilesButton: HTMLElement | null;
    fileNameDisplay: HTMLElement | null;
    fileUploaderSection: HTMLElement | null;
    capsulePreviewModal: HTMLElement | null;
    jsonPreviewContent: HTMLElement | null;
    cancelUploadButton: HTMLButtonElement | null;
    confirmUploadButton: HTMLButtonElement | null;

    // Monitor View
    monitorView: HTMLElement | null;
    monitorFilterTenant: HTMLInputElement | null;
    monitorFilterDate: HTMLInputElement | null;
    monitorFilterStatus: HTMLSelectElement | null;
    monitorCapsuleTable: HTMLElement | null;
    monitorDetailsPane: HTMLElement | null;
    monitorSelectedCapsuleInfo: HTMLElement | null;
    esgChartCanvas: HTMLCanvasElement | null;
    esgQualitativeInfo: HTMLElement | null;
    monitorRefusalLogPane: HTMLElement | null;
    refusalLogDisplay: HTMLElement | null;

    // API Credentials View
    apiCredentialsView: HTMLElement | null;
    createApiKeyBtn: HTMLButtonElement | null;
    apiKeysTableBody: HTMLElement | null;
    coreApiEndpointsContainer: HTMLElement | null;
    createApiKeyModal: HTMLElement | null;
    closeCreateApiKeyModalBtn: HTMLElement | null;
    createApiKeyForm: HTMLFormElement | null;
    apiKeyNameInput: HTMLInputElement | null;
    newApiKeyDisplayArea: HTMLElement | null;
    newApiKeyValue: HTMLElement | null;
    copyNewApiKeyBtn: HTMLButtonElement | null;
    cancelCreateApiKeyBtn: HTMLButtonElement | null;
    submitCreateApiKeyBtn: HTMLButtonElement | null;
    doneCreateApiKeyBtn: HTMLButtonElement | null;

    // Integrations View
    integrationsView: HTMLElement | null;
    integrationsAccordionHeaders: NodeListOf<HTMLElement>;

    // AI Companion View
    aiCompanionView: HTMLElement | null;
    chatHistoryElement: HTMLElement | null;
    chatInputElement: HTMLInputElement | null;
    chatSendButton: HTMLButtonElement | null;

    // Student Program View
    studentProgramView: HTMLElement | null;
    studentApplicationForm: HTMLFormElement | null;

    // Support View
    supportView: HTMLElement | null;
    supportAccordionHeaders: NodeListOf<HTMLElement>;
    contactSupportForm: HTMLFormElement | null;

    // Legal View
    legalView: HTMLElement | null;

    // Settings View
    settingsView: HTMLElement | null;
    userProfileForm: HTMLFormElement | null;
    passwordChangeForm: HTMLFormElement | null;
    apiKeysForm: HTMLFormElement | null; // This is for 3rd party keys in settings
    profileNameInput: HTMLInputElement | null;
    profileEmailInput: HTMLInputElement | null;
    settingsSupabaseKeyInput: HTMLInputElement | null;
    settingsFirebaseTokenInput: HTMLInputElement | null;


    // Add other DOM elements as needed
    [key: string]: any; // Allow dynamic assignment for tab panes etc.
}

// --- GLOBAL STATE ---
const appData: AppData = {
    currentUser: null,
    capsules: [
        { id: "cap_001", tenant: "AcmeCorp", version: "1.2.0", status: 'Completed', executed_at: "2023-10-26T10:00:00Z", ipfs_hash: "Qm...", ethereum_tx_id: "0x...", esgScore: 85, refusalLog: "", esgQualitativeInsights: "Reduced carbon footprint by 15% this cycle." },
        { id: "cap_002", tenant: "BetaInc", version: "1.0.0", status: 'Executing', executed_at: "2023-10-26T10:05:00Z", esgScore: null, refusalLog: "" },
        { id: "cap_003", tenant: "AcmeCorp", version: "1.2.1", status: 'Pending', executed_at: "2023-10-26T10:10:00Z", esgScore: null, refusalLog: "" },
        { id: "cap_004", tenant: "GammaLLC", version: "2.0.0", status: 'Failed', executed_at: "2023-10-25T14:00:00Z", refusalLog: "Critical: ESG score below threshold (30).", esgScore: 30 },
        { id: "cap_005", tenant: "AcmeCorp", version: "1.1.0", status: 'Refused', executed_at: "2023-10-25T18:00:00Z", refusalLog: "Policy Violation: Unsafe operational parameters detected. Execution refused by Bonnie 2.0.", esgScore: 65, esgQualitativeInsights: "Attempted execution outside of approved parameters." },
    ],
    selectedCapsuleIdMonitor: null,
    chat: null,
    chatHistory: [],
    currentView: 'home',
    homePillarDetails: {
        ingestion: { title: "BonnieX Data Ingestion & Normalization", content: "This pillar focuses on reliably receiving data from various enterprise systems, APIs, IoT devices, or manual inputs. It validates data integrity, normalizes formats, and prepares it for the decision-making core. Key functions: schema validation, data type conversion, and secure input channels.", aiPrompt: "Explain BonnieX Data Ingestion & Normalization like I'm five." },
        decision: { title: "Clyde Alpha Decision Relay", content: "The heart of the system. This pillar takes normalized data and applies business logic, policy rules (e.g., via Open Policy Agent), and contextual knowledge to make deterministic decisions. It decides whether an action should proceed, be modified, or refused based on pre-set criteria and real-time inputs like ESG scores. Key functions: rule engine execution, policy enforcement, contextual analysis.", aiPrompt: "Explain Clyde Alpha Decision Relay like I'm five." },
        traceability: { title: "Blockchain & ESG Traceability Layer", content: "Ensures transparency and auditability. Every significant decision, execution, or refusal is cryptographically hashed and anchored to a public blockchain (like Ethereum). This layer also integrates real-time ESG (Environmental, Social, Governance) data to inform decisions and records ESG impact. Key functions: IPFS storage for logs, blockchain transaction creation, ESG data fetching and integration.", aiPrompt: "Explain Blockchain & ESG Traceability like I'm five." },
        orchestration: { title: "API Orchestration (Powered by n8n)", content: "Manages the execution of actions that involve multiple steps or interact with various external APIs. This pillar leverages workflow automation tools (like a conceptual n8n integration) to chain API calls, transform data between services, and handle complex operational sequences. Key functions: workflow execution, API integration, conditional logic for multi-step processes.", aiPrompt: "Explain API Orchestration like I'm five." },
        execution: { title: "Real-time Sovereign Execution Layer", content: "The final stage where approved actions are carried out. This layer utilizes scalable and resilient infrastructure like serverless functions (e.g., AWS Lambda, Vercel Edge Functions) to perform tasks. It ensures fault isolation, elastic scaling, and supports multi-tenant operations securely. Key functions: serverless function invocation, secure credential management, real-time action execution.", aiPrompt: "Explain Real-time Sovereign Execution Layer like I'm five." },
    },
    homeStrategicTabsContent: {
        "supply-chain": { title: "Automated Supply Chain Optimization", content: "In automated supply chains, Bonnie 2.0 can autonomously execute procurement orders when inventory levels fall. Concurrently, it can cross-reference supplier ESG scores in real-time. If a supplier's rating drops below a set threshold, the system will proactively refuse the order and log the refusal on a blockchain for a transparent audit trail." },
        "financial-trading": { title: "Compliant Algorithmic Trading", content: "Bonnie 2.0 can execute algorithmic trading strategies while ensuring adherence to regulatory compliance (e.g., MiFID II) and internal risk policies. It can proactively halt trades that might violate these rules and provide a full audit log of all decisions, including refused trades due to compliance breaches." },
        "smart-manufacturing": { title: "Predictive Maintenance & Quality Control", content: "In smart manufacturing, Bonnie 2.0 can monitor sensor data from machinery. If predictive analytics indicate an impending failure or a drop in quality standards, it can autonomously schedule maintenance or adjust production parameters, logging all actions and sensor readings for traceability and ESG impact assessment (e.g., energy consumption changes)." },
        "healthcare": { title: "Personalized Medicine & Patient Adherence", content: "Bonnie 2.0 can manage personalized treatment plans, adjusting medication dosages based on real-time patient data from wearables, while ensuring HIPAA compliance. It can send reminders, track adherence, and alert healthcare providers to critical deviations, all while maintaining an auditable record of patient interactions and data handling." }
    },
    smartManufacturingData: {
        statusText: 'ACTIVE',
        productionCapsules: 0,
        esgCompliance: 0,
        autoRefusals: 0,
        lastUpdated: new Date().toISOString(),
        executionEngine: {
            status: 'ACTIVE',
            executionCycles: 0,
            currentCapsuleId: 'N/A',
            processingEfficiency: 0,
        },
        decisionLog: [],
        pipelineStages: {
            rawMaterialValidation: { id: 'raw', name: 'Raw Material Validation', status: 'Active', progress: 0, capsulesInStage: 0 },
            smartManufacturing: { id: 'mfg', name: 'Smart Manufacturing', status: 'Active', progress: 0, capsulesInStage: 0 },
            inlineQualityControl: { id: 'qc', name: 'Inline Quality Control', status: 'Active', progress: 0, capsulesInStage: 0 },
            conditionalPackaging: { id: 'pkg', name: 'Conditional Packaging', status: 'Waiting', progress: 0, capsulesInStage: 0 },
        },
        productionMetrics: { tonsOutput: 0, esgRate: 0},
        efficiencyMetrics: { avgDecisionTime: 0, uptime: 99.98},
        qualityRefusals: { batchesToday: 0, refusalRate: 0}
    },
    simulationIntervalId: null,
    apiKeys: [
        { id: 'key_1', name: 'Default Test Key', key: 'ca_sec_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxx', prefix: 'ca_sec_test_', preview: 'ca_sec_test_...xxxx', createdAt: new Date(Date.now() - 86400000 * 5).toISOString(), status: 'Active', scopes: ['read:capsules', 'read:logs'], lastUsed: new Date(Date.now() - 3600000).toISOString() },
        { id: 'key_2', name: 'Old Integration Key', key: 'ca_sec_old_yyyyyyyyyyyyyyyyyyyyyyyyyyyy', prefix: 'ca_sec_old_', preview: 'ca_sec_old_...yyyy', createdAt: new Date(Date.now() - 86400000 * 30).toISOString(), status: 'Revoked', scopes: ['execute:capsules'] },
    ],
    clydeAlphaApiEndpoints: [
        { method: 'POST', path: '/capsules/execute', description: 'Triggers the execution of a specified capsule.', parameters: [{name: 'capsuleId', type: 'string', description: 'The ID of the capsule to execute.', required: true}], exampleRequest: '{ "capsuleId": "cap_123", "parameters": { "param1": "value1" } }' },
        { method: 'GET', path: '/capsules/{capsuleId}/status', description: 'Retrieves the current status and logs of a capsule execution.', parameters: [{name: 'capsuleId', type: 'string', description: 'The ID of the capsule.', required: true}] },
        { method: 'GET', path: '/capsules', description: 'Lists all available capsules for the authenticated user.', parameters: [{name: 'limit', type: 'integer', description: 'Number of capsules to return.', required: false}, {name: 'offset', type: 'integer', description: 'Offset for pagination.', required: false}] },
        { method: 'POST', path: '/capsules/upload', description: 'Uploads a new capsule definition.', exampleRequest: '{ "name": "New Processing Capsule", "definition": { ... } }' },
        { method: 'GET', path: '/esg/reports/{reportId}', description: 'Fetches a specific ESG compliance report.', parameters: [{ name: 'reportId', type: 'string', description: 'The ID of the ESG report.', required: true}] },
    ],
    config: {
        CORE_API_BASE_URL: '/api/mock/v1' // Example: In production, this would be an absolute URL.
                                        // For local dev, could point to a local mock server or a real dev backend.
    }
};

const dom: DomElements = {
    views: null!,
    navLinks: null!,
    mobileMenuButton: null,
    mobileMenu: null,
    toastNotification: null,
    mainHeader: null,
    homePageElements: null!,
    dashboardElements: null!,
    dashboardTitleHeader: null,
    dashboardSubtitleHeader: null,

    homeView: null,
    homeExploreCapabilitiesBtn: null,
    homeGenerateUsecaseBtn: null,
    pillarItems: null!,
    pillarDetailTitle: null,
    pillarDetailContent: null,
    pillarAIExplanation: null,
    pillarAIExplanationContent: null,
    simplifyExplanationBtns: null!,
    aiExplanationModal: null,
    aiExplanationModalTitle: null,
    aiExplanationModalContent: null,
    closeAiExplanationModalBtn: null,
    strategicValueTabs: null!,
    strategicValueContentPanes: null!,
    bonnie2LaunchButton: null,
    simulatorLaunchDashboardBtn: null,
    simulatorEnterControlDashboardBtn: null,

    loginView: null,
    emailInput: null,
    passwordInput: null,
    roleSelect: null,
    loginButton: null,
    signupButton: null,

    dashboardView: null,
    dashboardTabs: null!,
    dashboardTabPanesContainer: null,
    dashboardCapsuleTable: null,

    smartManufacturingView: null,
    smLastUpdated: null,
    smStatusIcon: null,
    smStatusText: null,
    smProdCapsules: null,
    smEsgCompliance: null,
    smAutoRefusals: null,
    smEngineStatus: null,
    smExecCycles: null,
    smCurrentCapsule: null,
    smProcEfficiencyValue: null,
    smProcEfficiencyBar: null,
    smPauseExecutionBtn: null,
    smPauseBtnIcon: null,
    smPauseBtnText: null,
    smDecisionLog: null,
    smPipelineTabs: null!,
    smPipelineTabContentPanes: null!,
    smCapsuleInspectorContent: null,
    smFloatingChatBtn: null,
    smPipelineRawStatus: null, smPipelineRawProgress: null, smPipelineRawProgressVal: null, smPipelineRawCapsules: null,
    smPipelineMfgStatus: null, smPipelineMfgProgress: null, smPipelineMfgProgressVal: null, smPipelineMfgCapsules: null,
    smPipelineQcStatus: null, smPipelineQcProgress: null, smPipelineQcProgressVal: null, smPipelineQcCapsules: null,
    smPipelinePkgStatus: null, smPipelinePkgProgress: null, smPipelinePkgProgressVal: null, smPipelinePkgCapsules: null,
    smProdMetricsTons: null, smProdMetricsEsgRate: null,
    smEfficiencyTime: null, smEfficiencyUptime: null,
    smQualityRefusalsBatches: null, smQualityRefusalsRate: null,

    capsuleUploaderView: null,
    capsuleFileInput: null,
    browseFilesButton: null,
    fileNameDisplay: null,
    fileUploaderSection: null,
    capsulePreviewModal: null,
    jsonPreviewContent: null,
    cancelUploadButton: null,
    confirmUploadButton: null,

    monitorView: null,
    monitorFilterTenant: null,
    monitorFilterDate: null,
    monitorFilterStatus: null,
    monitorCapsuleTable: null,
    monitorDetailsPane: null,
    monitorSelectedCapsuleInfo: null,
    esgChartCanvas: null,
    esgQualitativeInfo: null,
    monitorRefusalLogPane: null,
    refusalLogDisplay: null,

    apiCredentialsView: null,
    createApiKeyBtn: null,
    apiKeysTableBody: null,
    coreApiEndpointsContainer: null,
    createApiKeyModal: null,
    closeCreateApiKeyModalBtn: null,
    createApiKeyForm: null,
    apiKeyNameInput: null,
    newApiKeyDisplayArea: null,
    newApiKeyValue: null,
    copyNewApiKeyBtn: null,
    cancelCreateApiKeyBtn: null,
    submitCreateApiKeyBtn: null,
    doneCreateApiKeyBtn: null,

    integrationsView: null,
    integrationsAccordionHeaders: null!,

    aiCompanionView: null,
    chatHistoryElement: null,
    chatInputElement: null,
    chatSendButton: null,

    studentProgramView: null,
    studentApplicationForm: null,

    supportView: null,
    supportAccordionHeaders: null!,
    contactSupportForm: null,

    legalView: null,

    settingsView: null,
    userProfileForm: null,
    passwordChangeForm: null,
    apiKeysForm: null,
    profileNameInput: null,
    profileEmailInput: null,
    settingsSupabaseKeyInput: null,
    settingsFirebaseTokenInput: null,
};

// --- GEMINI API SETUP ---
let ai: GoogleGenAI | null = null;
const GEMINI_MODEL_TEXT = 'gemini-2.5-flash-preview-04-17';

function initializeGemini() {
    try {
        if (process.env.API_KEY) {
            ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        } else {
            console.warn("API_KEY environment variable not found. AI Companion functionality will be limited.");
            showToast("AI Companion disabled: API_KEY not configured.", "error");
        }
    } catch (error) {
        console.error("Error initializing Gemini API:", error);
        showToast("Failed to initialize AI Companion.", "error");
    }
}


// --- UTILITY FUNCTIONS ---
function showToast(message: string, type: 'info' | 'success' | 'error' = 'info', duration: number = 3000) {
    if (!dom.toastNotification) return;
    dom.toastNotification.textContent = message;
    dom.toastNotification.className = 'fixed bottom-5 right-5 text-white py-2 px-4 rounded-lg shadow-lg z-80'; // Reset classes
    
    if (type === 'success') {
        dom.toastNotification.classList.add('bg-green-600');
    } else if (type === 'error') {
        dom.toastNotification.classList.add('bg-red-600');
    } else {
        dom.toastNotification.classList.add('bg-gray-800');
    }
    dom.toastNotification.classList.remove('hidden');
    
    setTimeout(() => {
        dom.toastNotification?.classList.add('hidden');
    }, duration);
}

function formatDate(dateString?: string, includeTime = true): string {
    if (!dateString) return 'N/A';
    try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return 'Invalid Date';
        const options: Intl.DateTimeFormatOptions = {
            year: 'numeric', month: 'short', day: 'numeric',
        };
        if (includeTime) {
            options.hour = '2-digit';
            options.minute = '2-digit';
        }
        return date.toLocaleDateString(undefined, options);
    } catch (e) {
        return dateString; // fallback to original string if parsing fails
    }
}

function generateId(prefix: string = ''): string {
    return prefix + Math.random().toString(36).substr(2, 9);
}

// --- MOCK API SERVICE FUNCTIONS ---
// These functions simulate network requests. Replace with actual fetch/axios calls to your backend.
// The `appData.config.CORE_API_BASE_URL` would be used here.

async function mockApiCall<T>(data: T, successRate: number = 0.9): Promise<T> {
    const delay = 500 + Math.random() * 1000; // Simulate 0.5 to 1.5 seconds delay
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (Math.random() < successRate) {
                resolve(data);
            } else {
                reject(new Error("Mock API Error: The operation failed. Please try again."));
            }
        }, delay);
    });
}

async function uploadCapsuleAPI(capsuleData: Capsule): Promise<Capsule> {
    console.log(`[API MOCK] Uploading capsule: ${capsuleData.id} to ${appData.config.CORE_API_BASE_URL}/capsules`);
    // In a real scenario, you would use fetch:
    // const response = await fetch(`${appData.config.CORE_API_BASE_URL}/capsules`, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer YOUR_AUTH_TOKEN' },
    //   body: JSON.stringify(capsuleData)
    // });
    // if (!response.ok) throw new Error('Failed to upload capsule');
    // return await response.json();
    return mockApiCall(capsuleData);
}

async function createApiKeyAPI(name: string, scopes: string[] = ['read:all', 'write:all']): Promise<ApiKey> {
    console.log(`[API MOCK] Creating API key: ${name} at ${appData.config.CORE_API_BASE_URL}/apikeys`);
    const newKeyPrefix = "ca_sec_live_";
    const newFullApiKey = generateSecureApiKey(newKeyPrefix);
    const apiKey: ApiKey = {
        id: generateId('key_'),
        name: name,
        key: newFullApiKey, // This would typically be returned by the backend
        prefix: newKeyPrefix,
        preview: maskApiKeyDisplay(newFullApiKey, newKeyPrefix),
        createdAt: new Date().toISOString(),
        status: 'Active',
        scopes: scopes,
    };
    return mockApiCall(apiKey);
}

async function revokeApiKeyAPI(keyId: string): Promise<{ id: string, status: 'Revoked' }> {
    console.log(`[API MOCK] Revoking API key: ${keyId} at ${appData.config.CORE_API_BASE_URL}/apikeys/${keyId}`);
    return mockApiCall({ id: keyId, status: 'Revoked' });
}


// --- VIEW SWITCHING LOGIC ---
function switchView(viewId: string) {
    appData.currentView = viewId;
    dom.views.forEach(view => {
        if (view.id === `${viewId}-view`) {
            view.classList.add('active');
        } else {
            view.classList.remove('active');
        }
    });
    updateHeaderNav(viewId);
    
    if (viewId !== 'smart-manufacturing' && appData.simulationIntervalId !== null) {
        window.clearInterval(appData.simulationIntervalId);
        appData.simulationIntervalId = null;
        if (dom.smPauseBtnText) dom.smPauseBtnText.textContent = "Resume Execution";
        if (dom.smPauseBtnIcon) dom.smPauseBtnIcon.innerHTML = ICONS.play;
    } else if (viewId === 'smart-manufacturing' && appData.simulationIntervalId === null && appData.smartManufacturingData.executionEngine.status === 'ACTIVE') {
        startSmartManufacturingSimulation();
    }

    if (viewId === 'dashboard') renderDashboardView();
    else if (viewId === 'monitor') renderMonitorView();
    else if (viewId === 'smart-manufacturing') renderSmartManufacturingView();
    else if (viewId === 'api-credentials') renderApiCredentialsView();
    else if (viewId === 'home') renderHomeView();


    if (dom.mobileMenu && !dom.mobileMenu.classList.contains('hidden')) {
        dom.mobileMenu.classList.add('hidden');
        if (dom.mobileMenuButton) dom.mobileMenuButton.setAttribute('aria-expanded', 'false');
    }

    window.scrollTo(0, 0); 
    window.location.hash = viewId; // Update hash for deep linking
}

function updateHeaderNav(currentViewId: string) {
    const isHomePage = currentViewId === 'home';

    if (dom.mainHeader) {
        if (isHomePage) {
            dom.mainHeader.classList.remove('bg-white/80', 'shadow-sm');
            dom.mainHeader.classList.add('home-hero-bg'); 
        } else {
            dom.mainHeader.classList.remove('home-hero-bg');
            dom.mainHeader.classList.add('bg-white/80', 'shadow-sm');
        }
    }
    
    dom.homePageElements?.forEach(el => el.style.display = isHomePage ? '' : 'none');
    dom.dashboardElements?.forEach(el => el.style.display = isHomePage ? 'none' : '');
    
    if (dom.dashboardTitleHeader) dom.dashboardTitleHeader.style.display = isHomePage ? 'none' : '';
    if (dom.dashboardSubtitleHeader) dom.dashboardSubtitleHeader.style.display = isHomePage ? 'none' : '';


    dom.navLinks.forEach(link => {
        const linkView = link.getAttribute('data-view');
        const isHomeNavLink = link.classList.contains('home-nav-link');

        if (linkView === currentViewId) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
        if (isHomePage) {
            if (isHomeNavLink) link.style.display = ''; else link.style.display = 'none';
        } else {
            if (!isHomeNavLink) link.style.display = ''; else link.style.display = 'none';
        }

    });
     if (dom.bonnie2LaunchButton) dom.bonnie2LaunchButton.style.display = isHomePage ? '' : 'none';

    updateMobileMenu(isHomePage);
}

function updateMobileMenu(isHomePage: boolean) {
    if (!dom.mobileMenu) return;
    dom.mobileMenu.innerHTML = ''; 

    const linksToDisplay = Array.from(dom.navLinks).filter(link => {
        const isHomeNavLink = link.classList.contains('home-nav-link');
        return isHomePage ? isHomeNavLink : !isHomeNavLink;
    });
    
    if (isHomePage && dom.bonnie2LaunchButton) {
         linksToDisplay.push(dom.bonnie2LaunchButton as HTMLElement);
    }


    linksToDisplay.forEach(link => {
        const clonedLink = link.cloneNode(true) as HTMLElement;
        clonedLink.className = 'block nav-link px-3 py-2 rounded-md text-base font-medium';
        if (link.classList.contains('home-nav-link')) {
             clonedLink.classList.add('text-gray-300', 'hover:bg-gray-700', 'hover:text-white');
        } else {
             clonedLink.classList.add('text-gray-700', 'hover:bg-gray-100');
        }

        if (link.getAttribute('data-view') === appData.currentView) {
            clonedLink.classList.add('active', isHomePage ? 'bg-gray-900' : 'bg-gray-200');
        } else {
            clonedLink.classList.remove('active', 'bg-gray-900', 'bg-gray-200');
        }
        
        clonedLink.addEventListener('click', (e) => {
            e.preventDefault();
            const viewId = (e.currentTarget as HTMLElement).getAttribute('data-view');
            if (viewId) {
                switchView(viewId);
            }
            dom.mobileMenu?.classList.add('hidden');
            dom.mobileMenuButton?.setAttribute('aria-expanded', 'false');
        });
        dom.mobileMenu?.appendChild(clonedLink);
    });
}


// --- ICON DEFINITIONS ---
const ICONS = {
    pause: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />',
    play: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />',
};

// --- RENDER FUNCTIONS ---

function renderHomeView() {
    if (dom.pillarItems.length > 0) {
        handlePillarClick(dom.pillarItems[0] as HTMLElement); 
    }
    if (dom.strategicValueTabs.length > 0) {
        handleStrategicTabClick(dom.strategicValueTabs[0] as HTMLElement); 
    }
}


function renderLoginView() {
    if (dom.emailInput) dom.emailInput.value = '';
    if (dom.passwordInput) dom.passwordInput.value = '';
}

function renderDashboardView() {
    if (!dom.dashboardCapsuleTable || !dom.dashboardTabs || !dom.dashboardTabPanesContainer) return;

    const activeTab = dom.dashboardTabs[0]; 
    handleDashboardTabClick(activeTab);

    dom.dashboardCapsuleTable.innerHTML = ''; 
    appData.capsules.forEach(capsule => {
        const row = (dom.dashboardCapsuleTable as HTMLTableElement).insertRow();
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${capsule.id}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${capsule.version}</td>
            <td class="px-6 py-4 whitespace-nowrap"><span class="status-badge status-${capsule.status.toLowerCase()}">${capsule.status}</span></td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${formatDate(capsule.executed_at)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${capsule.ipfs_hash || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${capsule.ethereum_tx_id || 'N/A'}</td>
        `;
    });
}

function renderSmartManufacturingView() {
    if (!dom.smartManufacturingView) return;
    const data = appData.smartManufacturingData;

    if (dom.smLastUpdated) dom.smLastUpdated.textContent = `Last updated: ${formatDate(data.lastUpdated)}`;
    if (dom.smStatusText) dom.smStatusText.textContent = data.statusText;
    if (dom.smStatusIcon) {
        dom.smStatusIcon.innerHTML = data.statusText === 'ACTIVE' 
            ? `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>`
            : `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>`;
    }
    if (dom.smProdCapsules) dom.smProdCapsules.textContent = data.productionCapsules.toLocaleString();
    if (dom.smEsgCompliance) dom.smEsgCompliance.textContent = `${data.esgCompliance.toFixed(1)}%`;
    if (dom.smAutoRefusals) dom.smAutoRefusals.textContent = data.autoRefusals.toLocaleString();

    if (dom.smEngineStatus) {
        dom.smEngineStatus.textContent = data.executionEngine.status;
        dom.smEngineStatus.className = `text-xs px-2 py-0.5 rounded-full ${data.executionEngine.status === 'ACTIVE' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}`;
    }
    if (dom.smExecCycles) dom.smExecCycles.textContent = data.executionEngine.executionCycles.toLocaleString();
    if (dom.smCurrentCapsule) dom.smCurrentCapsule.textContent = data.executionEngine.currentCapsuleId;
    if (dom.smProcEfficiencyValue) dom.smProcEfficiencyValue.textContent = `${data.executionEngine.processingEfficiency.toFixed(0)}%`;
    if (dom.smProcEfficiencyBar) dom.smProcEfficiencyBar.style.width = `${data.executionEngine.processingEfficiency}%`;
    
    if (dom.smPauseBtnText) dom.smPauseBtnText.textContent = data.executionEngine.status === 'PAUSED' ? "Resume Execution" : "Pause Execution";
    if (dom.smPauseBtnIcon) dom.smPauseBtnIcon.innerHTML = data.executionEngine.status === 'PAUSED' ? ICONS.play : ICONS.pause;

    if (dom.smDecisionLog) {
        dom.smDecisionLog.innerHTML = '';
        const logToShow = data.decisionLog.slice(-10); 
        logToShow.reverse().forEach(entry => {
            const div = document.createElement('div');
            div.className = 'sm-decision-log-entry p-2 border-b border-gray-100 text-xs';
            let typeColor = 'text-gray-600';
            if (entry.type === 'SUCCESS' || entry.type === 'EXECUTION') typeColor = 'text-green-600';
            else if (entry.type === 'ERROR' || entry.type === 'REFUSAL') typeColor = 'text-red-600';
            else if (entry.type === 'WARNING') typeColor = 'text-yellow-600';
            else if (entry.type === 'COMPLIANCE') typeColor = 'text-blue-600';

            div.innerHTML = `
                <div class="flex justify-between items-center">
                    <span class="font-semibold ${typeColor}">${entry.type}</span>
                    <span class="text-gray-400">${formatDate(entry.timestamp)}</span>
                </div>
                <p class="text-gray-700 mt-0.5">${entry.message} <span class="font-mono text-indigo-500 text-[11px]">(${entry.capsuleId})</span></p>
                ${entry.details ? `<p class="text-gray-500 text-[11px] mt-0.5">${entry.details}</p>` : ''}
            `;
            dom.smDecisionLog!.appendChild(div);
        });
    }

    const stages = data.pipelineStages;
    Object.keys(stages).forEach(key => {
        const stage = stages[key as keyof typeof stages];
        const statusEl = dom[`smPipeline${capitalizeFirstLetter(stage.id)}Status`];
        const progressEl = dom[`smPipeline${capitalizeFirstLetter(stage.id)}Progress`];
        const progressValEl = dom[`smPipeline${capitalizeFirstLetter(stage.id)}ProgressVal`];
        const capsulesEl = dom[`smPipeline${capitalizeFirstLetter(stage.id)}Capsules`];

        if (statusEl) {
            statusEl.textContent = stage.status;
            statusEl.className = `status-badge status-${stage.status.toLowerCase()}`;
        }
        if (progressEl) progressEl.style.width = `${stage.progress}%`;
        if (progressValEl) progressValEl.textContent = `${stage.progress}%`;
        if (capsulesEl) capsulesEl.textContent = stage.capsulesInStage.toLocaleString();
    });

    if(dom.smProdMetricsTons) dom.smProdMetricsTons.textContent = `${data.productionMetrics.tonsOutput.toLocaleString()} tons`;
    if(dom.smProdMetricsEsgRate) dom.smProdMetricsEsgRate.textContent = `${data.productionMetrics.esgRate.toFixed(1)}%`;
    if(dom.smEfficiencyTime) dom.smEfficiencyTime.textContent = `${data.efficiencyMetrics.avgDecisionTime.toFixed(1)} sec`;
    if(dom.smEfficiencyUptime) dom.smEfficiencyUptime.textContent = `${data.efficiencyMetrics.uptime.toFixed(2)}%`;
    if(dom.smQualityRefusalsBatches) dom.smQualityRefusalsBatches.textContent = data.qualityRefusals.batchesToday.toLocaleString();
    if(dom.smQualityRefusalsRate) dom.smQualityRefusalsRate.textContent = `${data.qualityRefusals.refusalRate.toFixed(1)}%`;

    if (dom.smCapsuleInspectorContent && data.executionEngine.currentCapsuleId !== 'N/A') {
        const currentCapsule = appData.capsules.find(c => c.id === data.executionEngine.currentCapsuleId);
        dom.smCapsuleInspectorContent.innerHTML = currentCapsule
            ? `
                <h5 class="font-semibold text-gray-800">Capsule: ${currentCapsule.id}</h5>
                <p class="text-sm text-gray-600">Tenant: ${currentCapsule.tenant}</p>
                <p class="text-sm text-gray-600">Status: ${currentCapsule.status}</p>
                <p class="text-sm text-gray-600">ESG Score: ${currentCapsule.esgScore !== null ? currentCapsule.esgScore : 'N/A'}</p>
                <pre class="text-xs bg-gray-100 p-2 rounded mt-2 overflow-auto max-h-40">${JSON.stringify(currentCapsule.parameters || { info: "No parameters" }, null, 2)}</pre>
            `
            : `<p class="text-gray-600">Details for capsule ${data.executionEngine.currentCapsuleId} not found.</p>`;
    } else if (dom.smCapsuleInspectorContent) {
        dom.smCapsuleInspectorContent.innerHTML = `<p class="text-gray-600">No capsule currently processing or selected.</p>`;
    }
    
    const activeSmTab = Array.from(dom.smPipelineTabs).find(tab => tab.classList.contains('active')) || dom.smPipelineTabs[0];
    if (activeSmTab) {
        handleSmartManufacturingTabClick(activeSmTab);
    }
}

function renderCapsuleUploaderView() {
    if(dom.fileNameDisplay) dom.fileNameDisplay.textContent = '';
    if(dom.capsuleFileInput) dom.capsuleFileInput.value = ''; 
    if(dom.jsonPreviewContent) dom.jsonPreviewContent.textContent = '';
    if(dom.capsulePreviewModal) dom.capsulePreviewModal.classList.add('hidden');
    if(dom.confirmUploadButton) {
        dom.confirmUploadButton.disabled = false;
        dom.confirmUploadButton.textContent = 'Confirm & Deploy';
    }
}

let esgChartInstance: any = null; 

function renderMonitorView() {
    if (!dom.monitorCapsuleTable || !dom.monitorDetailsPane) return;

    const tenantFilter = dom.monitorFilterTenant?.value.toLowerCase() || '';
    const dateFilter = dom.monitorFilterDate?.value || '';
    const statusFilter = dom.monitorFilterStatus?.value || '';

    const filteredCapsules = appData.capsules.filter(capsule => {
        const matchesTenant = tenantFilter ? capsule.tenant.toLowerCase().includes(tenantFilter) : true;
        const matchesDate = dateFilter ? capsule.executed_at.startsWith(dateFilter) : true;
        const matchesStatus = statusFilter ? capsule.status === statusFilter : true;
        return matchesTenant && matchesDate && matchesStatus;
    });

    dom.monitorCapsuleTable.innerHTML = ''; 
    filteredCapsules.forEach(capsule => {
        const row = (dom.monitorCapsuleTable as HTMLTableElement).insertRow();
        row.className = "cursor-pointer hover:bg-gray-50 transition-colors";
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${capsule.id}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${capsule.tenant}</td>
            <td class="px-6 py-4 whitespace-nowrap"><span class="status-badge status-${capsule.status.toLowerCase()}">${capsule.status}</span></td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${formatDate(capsule.executed_at)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${capsule.ipfs_hash || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${capsule.ethereum_tx_id || 'N/A'}</td>
        `;
        row.addEventListener('click', () => selectCapsuleForMonitor(capsule.id));
    });

    if (appData.selectedCapsuleIdMonitor) {
        selectCapsuleForMonitor(appData.selectedCapsuleIdMonitor); 
    } else {
        if (dom.monitorDetailsPane) dom.monitorDetailsPane.innerHTML = '<p>Select a capsule from the log to see details.</p>';
        if (dom.monitorSelectedCapsuleInfo) dom.monitorSelectedCapsuleInfo.classList.add('hidden');
    }
}

function selectCapsuleForMonitor(capsuleId: string) {
    appData.selectedCapsuleIdMonitor = capsuleId;
    const capsule = appData.capsules.find(c => c.id === capsuleId);

    if (!capsule || !dom.monitorDetailsPane || !dom.monitorSelectedCapsuleInfo || !dom.esgChartCanvas || !dom.esgQualitativeInfo || !dom.refusalLogDisplay) return;

    dom.monitorDetailsPane.innerHTML = ''; 
    dom.monitorSelectedCapsuleInfo.classList.remove('hidden');
    
    if (esgChartInstance) {
        esgChartInstance.destroy();
    }
    const esgScore = capsule.esgScore !== null ? capsule.esgScore : 0;
    esgChartInstance = new Chart(dom.esgChartCanvas, {
        type: 'doughnut',
        data: {
            labels: ['ESG Score', 'Remaining'],
            datasets: [{
                data: [esgScore, 100 - esgScore],
                backgroundColor: ['#10B981' , '#E5E7EB' ],
                borderColor: ['#FFFFFF', '#FFFFFF'],
                borderWidth: 2,
                
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false },
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });
    const esgTextNode = document.getElementById('esg-score-value-text');
    if (esgTextNode) esgTextNode.remove(); 

    const centerText = document.createElement('div');
    centerText.id = 'esg-score-value-text';
    centerText.style.position = 'absolute';
    centerText.style.top = '50%';
    centerText.style.left = '50%';
    centerText.style.transform = 'translate(-50%, -50%)';
    centerText.style.textAlign = 'center';
    centerText.innerHTML = `<span class="text-3xl font-bold text-gray-700">${esgScore}</span><br><span class="text-xs text-gray-500">ESG Score</span>`;
    dom.esgChartCanvas.parentNode?.appendChild(centerText);


    dom.esgQualitativeInfo.innerHTML = `
        <h5 class="font-medium text-gray-700">Qualitative Insights:</h5>
        <p>${capsule.esgQualitativeInsights || 'No qualitative insights available.'}</p>
    `;

    if (capsule.status === 'Refused' || capsule.status === 'Failed') {
        dom.refusalLogDisplay.textContent = capsule.refusalLog || 'No refusal/error log available.';
        if(dom.monitorRefusalLogPane) dom.monitorRefusalLogPane.classList.remove('hidden');
    } else {
        dom.refusalLogDisplay.textContent = 'No refusal/error log for this capsule.';
         if(dom.monitorRefusalLogPane) dom.monitorRefusalLogPane.classList.add('hidden');
    }
}

function renderApiCredentialsView() {
    if (!dom.apiKeysTableBody || !dom.coreApiEndpointsContainer) return;

    dom.apiKeysTableBody.innerHTML = '';
    appData.apiKeys.forEach(apiKey => {
        const row = (dom.apiKeysTableBody as HTMLTableSectionElement).insertRow();
        row.innerHTML = `
            <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">${apiKey.name}</td>
            <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500 font-mono">${apiKey.preview}</td>
            <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${formatDate(apiKey.createdAt, false)}</td>
            <td class="px-4 py-3 whitespace-nowrap">
                <span class="status-badge ${apiKey.status === 'Active' ? 'status-approved' : 'status-revoked'}">
                    ${apiKey.status}
                </span>
            </td>
            <td class="px-4 py-3 whitespace-nowrap text-xs text-gray-500">${apiKey.scopes.join(', ') || 'N/A'}</td>
            <td class="px-4 py-3 whitespace-nowrap text-sm font-medium">
                ${apiKey.status === 'Active' ? `<button class="text-red-600 hover:text-red-800" data-key-id="${apiKey.id}" name="revoke-api-key-btn">Revoke</button>` : `<span class="text-gray-400">Revoked</span>`}
            </td>
        `;
        const revokeBtn = row.querySelector('button[name="revoke-api-key-btn"]');
        revokeBtn?.addEventListener('click', (e) => {
            const keyId = (e.currentTarget as HTMLElement).getAttribute('data-key-id');
            if (keyId) handleRevokeApiKey(keyId, e.currentTarget as HTMLButtonElement);
        });
    });

    dom.coreApiEndpointsContainer.innerHTML = '';
    appData.clydeAlphaApiEndpoints.forEach(endpoint => {
        const card = document.createElement('div');
        card.className = 'api-endpoint-card';
        card.innerHTML = `
            <div class="flex items-center mb-2">
                <span class="api-method api-method-${endpoint.method.toLowerCase()}">${endpoint.method}</span>
                <code class="text-sm font-semibold text-gray-700">${endpoint.path}</code>
            </div>
            <p class="text-sm text-gray-600">${endpoint.description}</p>
            ${endpoint.parameters ? `
                <div class="mt-3">
                    <h5 class="text-xs font-semibold text-gray-500 uppercase mb-1">Parameters:</h5>
                    <ul class="list-disc list-inside text-xs space-y-0.5">
                        ${endpoint.parameters.map(p => `<li><span class="font-medium">${p.name}</span> (${p.type})${p.required ? ' <strong class="text-red-500">*required</strong>' : ''}: ${p.description}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
            ${endpoint.exampleRequest ? `
                <div class="mt-3">
                    <h5 class="text-xs font-semibold text-gray-500 uppercase mb-1">Example Request:</h5>
                    <pre class="code-block text-xs p-2 rounded">${endpoint.exampleRequest}</pre>
                </div>
            ` : ''}
        `;
        dom.coreApiEndpointsContainer!.appendChild(card);
    });
}

function renderIntegrationsView() { /* Placeholder */ }
function renderAiCompanionView() { /* Placeholder for Gemini chat UI updates */ }
function renderStudentProgramView() { /* Placeholder */ }
function renderSupportView() { /* Placeholder */ }
function renderLegalView() { /* Placeholder */ }
function renderSettingsView() {
    if (appData.currentUser && dom.profileNameInput && dom.profileEmailInput) {
        dom.profileNameInput.value = appData.currentUser.name;
        dom.profileEmailInput.value = appData.currentUser.email;
    }
     if (dom.settingsSupabaseKeyInput && appData.currentUser?.supabase_api_key_ref) {
        dom.settingsSupabaseKeyInput.value = appData.currentUser.supabase_api_key_ref; 
    }
    if (dom.settingsFirebaseTokenInput && appData.currentUser?.firebase_api_token_ref) {
        dom.settingsFirebaseTokenInput.value = appData.currentUser.firebase_api_token_ref; 
    }
}


// --- API KEY MANAGEMENT LOGIC ---
function openCreateApiKeyModal() {
    if (!dom.createApiKeyModal || !dom.createApiKeyForm) return;
    resetCreateApiKeyModalForm();
    dom.createApiKeyModal.classList.remove('hidden');
    dom.apiKeyNameInput?.focus();
}

function closeCreateApiKeyModal() {
    if (!dom.createApiKeyModal) return;
    dom.createApiKeyModal.classList.add('hidden');
    resetCreateApiKeyModalForm();
}

function resetCreateApiKeyModalForm() {
    if(dom.createApiKeyForm) dom.createApiKeyForm.reset();
    if(dom.newApiKeyDisplayArea) dom.newApiKeyDisplayArea.classList.add('hidden');
    if(dom.newApiKeyValue) dom.newApiKeyValue.textContent = '';
    if(dom.submitCreateApiKeyBtn) {
        dom.submitCreateApiKeyBtn.classList.remove('hidden');
        dom.submitCreateApiKeyBtn.disabled = false;
        dom.submitCreateApiKeyBtn.textContent = 'Create Key';
    }
    if(dom.doneCreateApiKeyBtn) dom.doneCreateApiKeyBtn.classList.add('hidden');
    if(dom.apiKeyNameInput) dom.apiKeyNameInput.disabled = false;
}

function generateSecureApiKey(prefix = "ca_sec_"): string {
    const randomPart = Array(32).fill(null).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
    return prefix + randomPart;
}

function maskApiKeyDisplay(fullKey: string, prefix: string): string {
    if (!fullKey.startsWith(prefix)) return "Invalid Key Format";
    const displayablePart = fullKey.substring(prefix.length);
    if (displayablePart.length <= 4) return prefix + displayablePart; 
    return `${prefix}••••••••${displayablePart.slice(-4)}`;
}


async function handleCreateApiKeyFormSubmit(event: Event) {
    event.preventDefault();
    if (!dom.apiKeyNameInput || !dom.newApiKeyDisplayArea || !dom.newApiKeyValue || !dom.submitCreateApiKeyBtn || !dom.doneCreateApiKeyBtn) return;

    const keyName = dom.apiKeyNameInput.value.trim();
    if (!keyName) {
        showToast("API Key name cannot be empty.", "error");
        return;
    }

    dom.submitCreateApiKeyBtn.disabled = true;
    dom.submitCreateApiKeyBtn.textContent = 'Creating...';

    try {
        const newApiKey = await createApiKeyAPI(keyName); // Mock API call
        appData.apiKeys.push(newApiKey);
        
        dom.newApiKeyValue.textContent = newApiKey.key; // Show the full key from mock response
        dom.newApiKeyDisplayArea.classList.remove('hidden');
        dom.submitCreateApiKeyBtn.classList.add('hidden');
        dom.doneCreateApiKeyBtn.classList.remove('hidden');
        dom.apiKeyNameInput.disabled = true;

        renderApiCredentialsView(); 
        showToast(`API Key "${keyName}" created successfully. Store it securely!`, "success", 5000);
    } catch (error: any) {
        console.error("Failed to create API key:", error);
        showToast(error.message || "Failed to create API key.", "error");
        dom.submitCreateApiKeyBtn.disabled = false;
        dom.submitCreateApiKeyBtn.textContent = 'Create Key';
    }
}

function handleCopyNewApiKeyToClipboard() {
    if (!dom.newApiKeyValue || !dom.newApiKeyValue.textContent) return;
    navigator.clipboard.writeText(dom.newApiKeyValue.textContent)
        .then(() => showToast("API Key copied to clipboard!", "success"))
        .catch(err => {
            console.error("Failed to copy API key: ", err);
            showToast("Failed to copy API key.", "error");
        });
}

async function handleRevokeApiKey(keyId: string, buttonElement: HTMLButtonElement) {
    const keyToRevoke = appData.apiKeys.find(k => k.id === keyId);
    if (!keyToRevoke) {
        showToast("Error: API Key not found for revocation.", "error");
        return;
    }

    if (confirm(`Are you sure you want to revoke the API key "${keyToRevoke.name}"? This action cannot be undone.`)) {
        const originalButtonText = buttonElement.textContent;
        buttonElement.disabled = true;
        buttonElement.textContent = 'Revoking...';

        try {
            await revokeApiKeyAPI(keyId); // Mock API call
            const keyIndex = appData.apiKeys.findIndex(k => k.id === keyId);
            if (keyIndex > -1) {
                appData.apiKeys[keyIndex].status = 'Revoked';
            }
            renderApiCredentialsView(); // Re-render to update the button to "Revoked" text
            showToast(`API Key "${keyToRevoke.name}" has been revoked.`, "info");
        } catch (error: any) {
            console.error("Failed to revoke API key:", error);
            showToast(error.message || "Failed to revoke API key.", "error");
            buttonElement.disabled = false;
            buttonElement.textContent = originalButtonText;
        }
    }
}


// --- SMART MANUFACTURING SIMULATION ---
function simulateSmartManufacturingData() {
    // In a production environment, this data would come from a backend via WebSockets or polling.
    // For example:
    // socket.on('smartManufacturingUpdate', (updatedData) => {
    //   appData.smartManufacturingData = { ...appData.smartManufacturingData, ...updatedData };
    //   renderSmartManufacturingView();
    // });
    // The simulation below is for frontend demonstration purposes.

    const data = appData.smartManufacturingData;

    data.lastUpdated = new Date().toISOString();
    data.productionCapsules += Math.floor(Math.random() * 5) + 1;
    data.esgCompliance = Math.min(99.9, Math.max(95.0, data.esgCompliance + (Math.random() - 0.5) * 0.1));
    
    data.executionEngine.executionCycles += Math.floor(Math.random() * 10) + 5;
    data.executionEngine.currentCapsuleId = `CAP-${new Date().getFullYear()}-${String(data.executionEngine.executionCycles).padStart(6, '0')}`;
    data.executionEngine.processingEfficiency = Math.min(100, Math.max(90, data.executionEngine.processingEfficiency + (Math.random() - 0.45) * 0.5));

    const decisionTypes: SmartManufacturingDecisionLogEntry['type'][] = ['INFO', 'SUCCESS', 'EXECUTION', 'COMPLIANCE'];
    if (Math.random() < 0.05) { 
        if (Math.random() < 0.5) {
            decisionTypes.push('WARNING');
        } else {
            decisionTypes.push(Math.random() < 0.7 ? 'ERROR' : 'REFUSAL');
            data.autoRefusals++;
        }
    }
    const randomDecisionType = decisionTypes[Math.floor(Math.random() * decisionTypes.length)];
    data.decisionLog.push({
        id: generateId('log_'),
        timestamp: new Date().toISOString(),
        type: randomDecisionType,
        message: `${randomDecisionType} event for capsule processing. Details: ${Math.random().toString(36).substring(7)}.`,
        capsuleId: data.executionEngine.currentCapsuleId,
        details: randomDecisionType === 'REFUSAL' ? 'ESG score below threshold or policy violation.' : undefined
    });
    if (data.decisionLog.length > 50) data.decisionLog.shift(); 

    ['rawMaterialValidation', 'smartManufacturing', 'inlineQualityControl', 'conditionalPackaging'].forEach(key => {
        const stage = data.pipelineStages[key as keyof typeof data.pipelineStages];
        stage.progress = Math.min(100, stage.progress + Math.floor(Math.random() * 10) + 5);
        stage.capsulesInStage += Math.floor(Math.random() * 3) -1; 
        if(stage.capsulesInStage < 0) stage.capsulesInStage = 0;

        if (stage.progress >= 100) {
            stage.progress = 0; 
            stage.status = 'Waiting'; 
        } else if (stage.status === 'Waiting' && stage.progress > 0) {
            stage.status = 'Active';
        }
        if (Math.random() < 0.02 && stage.status === 'Active') stage.status = 'Issue'; 
        else if (stage.status === 'Issue' && Math.random() < 0.2) stage.status = 'Active'; 
    });
    
    data.productionMetrics.tonsOutput += Math.random() * 10;
    data.productionMetrics.esgRate = data.esgCompliance;
    data.efficiencyMetrics.avgDecisionTime = Math.max(0.5, data.efficiencyMetrics.avgDecisionTime + (Math.random() - 0.5) * 0.2);
    data.qualityRefusals.batchesToday = data.autoRefusals; 
    data.qualityRefusals.refusalRate = (data.autoRefusals / data.productionCapsules) * 100 || 0;

    renderSmartManufacturingView();
}

function startSmartManufacturingSimulation() {
    if (appData.simulationIntervalId !== null) window.clearInterval(appData.simulationIntervalId); 
    appData.smartManufacturingData.executionEngine.status = 'ACTIVE';
    // Initial call to populate data immediately if needed, then set interval
    // This function could also establish a WebSocket connection in a real app:
    // connectToSmartManufacturingBackend(); 
    simulateSmartManufacturingData(); 
    appData.simulationIntervalId = window.setInterval(simulateSmartManufacturingData, 3000); 
    if (dom.smPauseBtnText) dom.smPauseBtnText.textContent = "Pause Execution";
    if (dom.smPauseBtnIcon) dom.smPauseBtnIcon.innerHTML = ICONS.pause;
}

function stopSmartManufacturingSimulation() {
    if (appData.simulationIntervalId !== null) {
        window.clearInterval(appData.simulationIntervalId);
        appData.simulationIntervalId = null;
    }
    // This function could also close a WebSocket connection:
    // disconnectFromSmartManufacturingBackend();
    appData.smartManufacturingData.executionEngine.status = 'PAUSED';
    if (dom.smPauseBtnText) dom.smPauseBtnText.textContent = "Resume Execution";
    if (dom.smPauseBtnIcon) dom.smPauseBtnIcon.innerHTML = ICONS.play;
    renderSmartManufacturingView(); 
}

function toggleSmartManufacturingSimulation() {
    if (appData.smartManufacturingData.executionEngine.status === 'PAUSED') {
        startSmartManufacturingSimulation();
    } else {
        stopSmartManufacturingSimulation();
    }
}


// --- HOME PAGE SPECIFIC LOGIC ---
function handlePillarClick(pillarElement: HTMLElement) {
    const pillarKey = pillarElement.dataset.pillar;
    if (!pillarKey || !dom.pillarDetailTitle || !dom.pillarDetailContent) return;

    dom.pillarItems.forEach(item => item.classList.remove('active'));
    pillarElement.classList.add('active');

    const details = appData.homePillarDetails[pillarKey];
    if (details) {
        dom.pillarDetailTitle.textContent = details.title;
        dom.pillarDetailContent.textContent = details.content;
        if(dom.pillarAIExplanation) dom.pillarAIExplanation.classList.add('hidden'); 
    }
}

async function handleSimplifyExplanation(event: MouseEvent) {
    const button = event.currentTarget as HTMLButtonElement;
    const pillarItem = button.closest('.pillar-item') as HTMLElement;
    const pillarKey = pillarItem?.dataset.pillar;

    if (!pillarKey || !dom.pillarAIExplanation || !dom.pillarAIExplanationContent || !dom.aiExplanationModal || !dom.aiExplanationModalContent || !dom.aiExplanationModalTitle) return;
    
    const details = appData.homePillarDetails[pillarKey];
    if (!details || !details.aiPrompt) return;

    if (!ai) {
        showToast("AI Companion is not initialized. Cannot simplify explanation.", "error");
        initializeGemini(); 
        if(!ai) return;
    }
    
    dom.aiExplanationModalTitle!.textContent = `Bonnie AI Explains: ${details.title}`;
    dom.aiExplanationModalContent!.innerHTML = '<p class="text-center py-4">✨ Thinking...</p>';
    dom.aiExplanationModal.classList.remove('hidden');

    button.disabled = true;
    const originalButtonText = button.innerHTML;
    button.innerHTML = '✨ Simplifying...';

    try {
        const response = await ai.models.generateContent({
            model: GEMINI_MODEL_TEXT,
            contents: [{ role: "user", parts: [{text: details.aiPrompt}] }],
        });
        dom.aiExplanationModalContent!.innerHTML = `<p>${response.text.replace(/\n/g, '<br>')}</p>`;
    } catch (error) {
        console.error("Error getting AI explanation:", error);
        dom.aiExplanationModalContent!.innerHTML = '<p class="text-red-500">Sorry, I encountered an error while generating the explanation.</p>';
        showToast("Error generating AI explanation.", "error");
    } finally {
        button.disabled = false;
        button.innerHTML = originalButtonText;
    }
}


function handleStrategicTabClick(tabElement: HTMLElement) {
    const tabKey = tabElement.dataset.tab;
    if (!tabKey) return;

    dom.strategicValueTabs.forEach(tab => tab.classList.remove('active'));
    tabElement.classList.add('active');

    dom.strategicValueContentPanes.forEach(pane => {
        if (pane.dataset.tabContent === tabKey) {
            pane.classList.remove('hidden');
            const contentData = appData.homeStrategicTabsContent[tabKey];
            if(contentData) {
                const titleEl = pane.querySelector('h4');
                const pEl = pane.querySelector('p');
                if(titleEl) titleEl.textContent = contentData.title;
                if(pEl) pEl.textContent = contentData.content;
            }
        } else {
            pane.classList.add('hidden');
        }
    });
}


// --- DASHBOARD TAB LOGIC ---
function handleDashboardTabClick(tabElement: HTMLElement) {
    const tabId = tabElement.dataset.tab;
    if (!tabId || !dom.dashboardTabPanesContainer) return;

    dom.dashboardTabs.forEach(tab => tab.classList.remove('active'));
    tabElement.classList.add('active');

    const panes = dom.dashboardTabPanesContainer.querySelectorAll<HTMLElement>('.tab-pane');
    panes.forEach(pane => pane.classList.add('hidden'));
    
    const activePane = dom.dashboardTabPanesContainer.querySelector<HTMLElement>(`#${tabId}-tab-pane`);
    if (activePane) {
        activePane.classList.remove('hidden');
    } else if (tabId === 'deploy-capsule-nav') { 
        switchView('capsule-uploader');
    }
}

// --- SMART MANUFACTURING TAB LOGIC ---
function handleSmartManufacturingTabClick(tabElement: HTMLElement) {
    const tabId = tabElement.dataset.tab;
    if (!tabId || !dom.smPipelineTabContentPanes) return;

    dom.smPipelineTabs.forEach(tab => tab.classList.remove('active'));
    tabElement.classList.add('active');

    dom.smPipelineTabContentPanes.forEach(pane => {
        if (pane.dataset.tabContent === tabId) {
            pane.classList.remove('hidden');
             pane.classList.add('active');
        } else {
            pane.classList.remove('hidden'); 
            pane.classList.remove('active');
        }
    });
    if (tabId === 'capsule-inspector') {
        renderSmartManufacturingView(); 
    }
}


// --- AI COMPANION LOGIC ---
async function handleSendMessage() {
    if (!dom.chatInputElement || !dom.chatHistoryElement || !dom.chatSendButton) {
        if (!ai && dom.chatInputElement) showToast("AI Companion is not initialized.", "error");
        return;
    }
    const messageText = dom.chatInputElement.value.trim();
    if (!messageText || !ai) return;

    appendMessageToChatHistory('user', messageText);
    dom.chatInputElement.value = '';
    dom.chatInputElement.disabled = true;
    dom.chatSendButton.disabled = true;
    const originalSendButtonText = dom.chatSendButton.textContent;
    dom.chatSendButton.textContent = 'Sending...';
    
    appendMessageToChatHistory('model', 'Thinking...', true); 

    try {
        if (!appData.chat) {
            appData.chat = ai.chats.create({model: GEMINI_MODEL_TEXT});
        }
        
        const response: GenerateContentResponse = await appData.chat.sendMessage({ message: messageText });
        
        const thinkingMessage = dom.chatHistoryElement.querySelector('.message-thinking');
        if (thinkingMessage) thinkingMessage.remove();
        
        appendMessageToChatHistory('model', response.text);

    } catch (error) {
        console.error("Error sending message to Gemini:", error);
        const thinkingMessage = dom.chatHistoryElement.querySelector('.message-thinking');
        if (thinkingMessage) thinkingMessage.remove();
        appendMessageToChatHistory('model', "Sorry, I encountered an error. Please try again.");
        showToast("Error communicating with AI Companion.", "error");
    } finally {
        dom.chatInputElement.disabled = false;
        dom.chatSendButton.disabled = false;
        dom.chatSendButton.textContent = originalSendButtonText || 'Send';
        dom.chatInputElement.focus();
    }
}

function appendMessageToChatHistory(role: AIChatMessage['role'], text: string, isThinking: boolean = false) {
    if (!dom.chatHistoryElement) return;
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('flex', 'mb-4', role === 'user' ? 'justify-end' : 'justify-start');
    if (isThinking) messageDiv.classList.add('message-thinking');

    const messageBubble = document.createElement('div');
    messageBubble.classList.add('p-3', 'rounded-lg', 'max-w-lg', role === 'user' ? 'bg-[#8a6d3b] text-white' : 'bg-gray-200 text-gray-800');
    messageBubble.innerHTML = `<p class="text-sm">${text.replace(/\n/g, '<br>')}</p>`;
    
    messageDiv.appendChild(messageBubble);
    dom.chatHistoryElement.appendChild(messageDiv);
    dom.chatHistoryElement.scrollTop = dom.chatHistoryElement.scrollHeight;

    if (role !== 'system') { 
        appData.chatHistory.push({ role, message: text, timestamp: new Date().toISOString() });
    }
}

// --- FILE UPLOADER LOGIC ---
function handleFileSelect(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
        const file = input.files[0];
        previewFile(file);
    }
}

function handleDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    dom.fileUploaderSection?.classList.add('border-blue-500', 'bg-blue-50');
}

function handleDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    dom.fileUploaderSection?.classList.remove('border-blue-500', 'bg-blue-50');
}

function handleDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    dom.fileUploaderSection?.classList.remove('border-blue-500', 'bg-blue-50');
    if (event.dataTransfer && event.dataTransfer.files.length > 0) {
        const file = event.dataTransfer.files[0];
        if (file.type === "application/json") {
            previewFile(file);
        } else {
            showToast("Invalid file type. Please upload a JSON file.", "error");
        }
    }
}

function previewFile(file: File) {
    if(dom.fileNameDisplay) dom.fileNameDisplay.textContent = `Selected file: ${file.name}`;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const jsonContent = JSON.parse(e.target?.result as string);
            if(dom.jsonPreviewContent) dom.jsonPreviewContent.textContent = JSON.stringify(jsonContent, null, 2);
            if(dom.capsulePreviewModal) dom.capsulePreviewModal.classList.remove('hidden');
        } catch (err) {
            showToast("Error parsing JSON file. Please ensure it's valid JSON.", "error");
            if(dom.fileNameDisplay) dom.fileNameDisplay.textContent = '';
        }
    };
    reader.readAsText(file);
}

async function handleConfirmUpload() {
    if (!dom.jsonPreviewContent || !dom.confirmUploadButton) return;
    
    const originalButtonText = dom.confirmUploadButton.textContent;
    dom.confirmUploadButton.disabled = true;
    dom.confirmUploadButton.textContent = 'Deploying...';

    try {
        const newCapsuleData = JSON.parse(dom.jsonPreviewContent.textContent || '{}') as Capsule;
        if (!newCapsuleData.id || !newCapsuleData.tenant || !newCapsuleData.version) {
            throw new Error("Capsule data is missing required fields (id, tenant, version).");
        }
        newCapsuleData.status = newCapsuleData.status || 'Pending';
        newCapsuleData.executed_at = newCapsuleData.executed_at || new Date().toISOString();
        newCapsuleData.esgScore = newCapsuleData.esgScore === undefined ? null : newCapsuleData.esgScore;
        newCapsuleData.refusalLog = newCapsuleData.refusalLog || "";

        await uploadCapsuleAPI(newCapsuleData); // Mock API Call

        appData.capsules.unshift(newCapsuleData); 
        showToast(`Capsule "${newCapsuleData.id}" uploaded successfully!`, 'success');
        if(dom.capsulePreviewModal) dom.capsulePreviewModal.classList.add('hidden');
        renderCapsuleUploaderView(); // Resets the uploader view
        switchView('monitor'); 
    } catch (err: any) {
        console.error("Error confirming upload:", err);
        showToast(`Error processing capsule: ${err.message || 'Invalid JSON structure.'}`, "error");
    } finally {
        if (dom.confirmUploadButton) {
            dom.confirmUploadButton.disabled = false;
            dom.confirmUploadButton.textContent = originalButtonText || 'Confirm & Deploy';
        }
    }
}


// --- ACCORDION LOGIC ---
function handleAccordionToggle(event: Event) {
    const button = event.currentTarget as HTMLElement;
    const content = button.nextElementSibling as HTMLElement;
    const expanded = button.getAttribute('aria-expanded') === 'true' || false;
    button.setAttribute('aria-expanded', String(!expanded));
    content.classList.toggle('hidden');
    const icon = button.querySelector('span:last-child');
    if (icon) icon.innerHTML = expanded ? '&#9660;' : '&#9650;'; 
}

function capitalizeFirstLetter(string: string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// --- EVENT LISTENERS ---
function initEventListeners() {
    dom.navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const viewId = (e.currentTarget as HTMLElement).getAttribute('data-view');
            if (viewId) switchView(viewId);
        });
    });

    dom.mobileMenuButton?.addEventListener('click', () => {
        const isExpanded = dom.mobileMenuButton?.getAttribute('aria-expanded') === 'true' || false;
        dom.mobileMenuButton?.setAttribute('aria-expanded', String(!isExpanded));
        dom.mobileMenu?.classList.toggle('hidden');
    });

    dom.homeExploreCapabilitiesBtn?.addEventListener('click', () => {
        document.getElementById('capabilities')?.scrollIntoView({ behavior: 'smooth' });
    });
     dom.homeGenerateUsecaseBtn?.addEventListener('click', async (event) => {
        const button = event.currentTarget as HTMLButtonElement;
        const originalButtonText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '✨ Generating...';
        showToast("Generating use case idea with Bonnie AI...", "info");
        
        if (!ai) {
            showToast("AI not available for use case generation.", "error");
            initializeGemini();
            if(!ai) {
                 button.disabled = false;
                 button.innerHTML = originalButtonText;
                 return;
            }
        }
        try {
            const response = await ai.models.generateContent({
                model: GEMINI_MODEL_TEXT,
                contents: [{role: "user", parts: [{text: "Generate a novel and impactful use case for a Sovereign Execution Intelligence platform like Bonnie 2.0 in a specific industry. Be concise and creative."}]}],
            });
            const useCaseIdea = response.text;
             if (dom.aiExplanationModal && dom.aiExplanationModalTitle && dom.aiExplanationModalContent && dom.closeAiExplanationModalBtn) {
                dom.aiExplanationModalTitle.textContent = "Bonnie AI Use Case Idea";
                dom.aiExplanationModalContent.innerHTML = `<p>${useCaseIdea.replace(/\n/g, '<br>')}</p>`;
                dom.aiExplanationModal.classList.remove('hidden');
            } else {
                showToast(useCaseIdea, "success", 5000); 
            }

        } catch (error) {
            console.error("Error generating use case:", error);
            showToast("Could not generate use case idea at this time.", "error");
        } finally {
            button.disabled = false;
            button.innerHTML = originalButtonText;
        }
    });

    dom.pillarItems?.forEach(item => item.addEventListener('click', () => handlePillarClick(item)));
    dom.simplifyExplanationBtns?.forEach(btn => btn.addEventListener('click', handleSimplifyExplanation));
    dom.closeAiExplanationModalBtn?.addEventListener('click', () => dom.aiExplanationModal?.classList.add('hidden'));

    dom.strategicValueTabs?.forEach(tab => tab.addEventListener('click', () => handleStrategicTabClick(tab)));
    
    const launchDashboardActions = () => switchView('dashboard');
    dom.bonnie2LaunchButton?.addEventListener('click', launchDashboardActions);
    dom.simulatorLaunchDashboardBtn?.addEventListener('click', launchDashboardActions);
    dom.simulatorEnterControlDashboardBtn?.addEventListener('click', launchDashboardActions);


    dom.loginButton?.addEventListener('click', () => {
        const email = dom.emailInput?.value;
        if (email) {
            appData.currentUser = { name: "Demo User", email: email, role: 'Developer' };
            showToast(`Welcome, ${appData.currentUser.name}!`, 'success');
            switchView('dashboard');
        } else {
            showToast('Please enter an email.', 'error');
        }
    });
    dom.signupButton?.addEventListener('click', () => {
         const email = dom.emailInput?.value;
         const role = dom.roleSelect?.value as User['role'] || 'Student';
        if (email) {
            appData.currentUser = { name: "New User", email: email, role: role };
            showToast(`Account created for ${appData.currentUser.name}!`, 'success');
            switchView('dashboard'); 
        } else {
            showToast('Please enter an email to sign up.', 'error');
        }
    });

    dom.dashboardTabs?.forEach(tab => tab.addEventListener('click', () => handleDashboardTabClick(tab)));

    dom.smPauseExecutionBtn?.addEventListener('click', toggleSmartManufacturingSimulation);
    dom.smPipelineTabs?.forEach(tab => tab.addEventListener('click', () => handleSmartManufacturingTabClick(tab)));
    dom.smFloatingChatBtn?.addEventListener('click', () => switchView('ai-companion'));


    dom.browseFilesButton?.addEventListener('click', () => dom.capsuleFileInput?.click());
    dom.capsuleFileInput?.addEventListener('change', handleFileSelect);
    dom.fileUploaderSection?.addEventListener('dragover', handleDragOver);
    dom.fileUploaderSection?.addEventListener('dragleave', handleDragLeave);
    dom.fileUploaderSection?.addEventListener('drop', handleDrop);
    dom.cancelUploadButton?.addEventListener('click', () => {
        if(dom.capsulePreviewModal) dom.capsulePreviewModal.classList.add('hidden');
        renderCapsuleUploaderView(); // Reset the uploader view
    });
    dom.confirmUploadButton?.addEventListener('click', handleConfirmUpload);


    dom.monitorFilterTenant?.addEventListener('input', () => renderMonitorView());
    dom.monitorFilterDate?.addEventListener('change', () => renderMonitorView());
    dom.monitorFilterStatus?.addEventListener('change', () => renderMonitorView());

    dom.createApiKeyBtn?.addEventListener('click', openCreateApiKeyModal);
    dom.closeCreateApiKeyModalBtn?.addEventListener('click', closeCreateApiKeyModal);
    dom.cancelCreateApiKeyBtn?.addEventListener('click', closeCreateApiKeyModal);
    dom.createApiKeyForm?.addEventListener('submit', handleCreateApiKeyFormSubmit);
    dom.copyNewApiKeyBtn?.addEventListener('click', handleCopyNewApiKeyToClipboard);
    dom.doneCreateApiKeyBtn?.addEventListener('click', closeCreateApiKeyModal);


    dom.integrationsAccordionHeaders?.forEach(header => header.addEventListener('click', handleAccordionToggle));
    
    dom.chatSendButton?.addEventListener('click', handleSendMessage);
    dom.chatInputElement?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !dom.chatSendButton?.disabled) handleSendMessage();
    });

    dom.studentApplicationForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Application submitted (mock)!', 'success');
        (e.target as HTMLFormElement).reset();
    });

    dom.supportAccordionHeaders?.forEach(header => header.addEventListener('click', handleAccordionToggle));
    dom.contactSupportForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Support message sent (mock)!', 'success');
        (e.target as HTMLFormElement).reset();
    });
    
    dom.userProfileForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        if(appData.currentUser && dom.profileNameInput) {
            appData.currentUser.name = dom.profileNameInput.value;
            showToast('Profile updated!', 'success');
        }
    });
    dom.passwordChangeForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Password change requested (mock).', 'info');
        (e.target as HTMLFormElement).reset();
    });
     dom.apiKeysForm?.addEventListener('submit', (e) => { 
        e.preventDefault();
        if(appData.currentUser && dom.settingsSupabaseKeyInput && dom.settingsFirebaseTokenInput) {
            appData.currentUser.supabase_api_key_ref = dom.settingsSupabaseKeyInput.value;
            appData.currentUser.firebase_api_token_ref = dom.settingsFirebaseTokenInput.value;
            showToast('Third-party API keys saved (mock)!', 'success');
        }
    });

}


// --- INITIALIZATION ---
function queryDomElements() {
    dom.views = document.querySelectorAll('.view');
    dom.navLinks = document.querySelectorAll('.nav-link');
    dom.mobileMenuButton = document.getElementById('mobile-menu-button');
    dom.mobileMenu = document.getElementById('mobile-menu');
    dom.toastNotification = document.getElementById('toast-notification');
    dom.mainHeader = document.getElementById('main-header');
    dom.homePageElements = document.querySelectorAll('.home-page-element');
    dom.dashboardElements = document.querySelectorAll('.dashboard-element');
    dom.dashboardTitleHeader = document.getElementById('dashboard-title-header');
    dom.dashboardSubtitleHeader = document.getElementById('dashboard-subtitle-header');


    dom.homeView = document.getElementById('home-view') as HTMLElement;
    dom.homeExploreCapabilitiesBtn = document.getElementById('home-explore-capabilities-btn');
    dom.homeGenerateUsecaseBtn = document.getElementById('home-generate-usecase-btn');
    dom.pillarItems = document.querySelectorAll('.pillar-item');
    dom.pillarDetailTitle = document.getElementById('pillar-detail-title');
    dom.pillarDetailContent = document.getElementById('pillar-detail-content');
    dom.pillarAIExplanation = document.getElementById('pillar-ai-explanation');
    dom.pillarAIExplanationContent = document.getElementById('pillar-ai-explanation-content');
    dom.simplifyExplanationBtns = document.querySelectorAll('.simplify-explanation-btn');
    dom.aiExplanationModal = document.getElementById('ai-explanation-modal');
    dom.aiExplanationModalTitle = document.getElementById('ai-explanation-modal-title');
    dom.aiExplanationModalContent = document.getElementById('ai-explanation-modal-content');
    dom.closeAiExplanationModalBtn = document.getElementById('close-ai-explanation-modal-btn');
    dom.strategicValueTabs = document.querySelectorAll('#strategic-value-tabs .strategic-tab');
    dom.strategicValueContentPanes = document.querySelectorAll('#strategic-value-content .strategic-tab-pane');
    dom.bonnie2LaunchButton = document.getElementById('bonnie-2-launch-button');
    dom.simulatorLaunchDashboardBtn = document.getElementById('simulator-launch-dashboard-btn');
    dom.simulatorEnterControlDashboardBtn = document.getElementById('simulator-enter-control-dashboard-btn');

    dom.loginView = document.getElementById('login-view') as HTMLElement;
    dom.emailInput = document.getElementById('email-input') as HTMLInputElement;
    dom.passwordInput = document.getElementById('password-input') as HTMLInputElement;
    dom.roleSelect = document.getElementById('role-select') as HTMLSelectElement;
    dom.loginButton = document.getElementById('login-button');
    dom.signupButton = document.getElementById('signup-button');

    dom.dashboardView = document.getElementById('dashboard-view') as HTMLElement;
    dom.dashboardTabs = document.querySelectorAll('#dashboard-tabs .tab-button');
    dom.dashboardTabPanesContainer = document.getElementById('dashboard-tab-content');
    dom.dashboardCapsuleTable = document.getElementById('dashboard-capsule-table') as HTMLElement;

    dom.smartManufacturingView = document.getElementById('smart-manufacturing-view') as HTMLElement;
    dom.smLastUpdated = document.getElementById('sm-last-updated');
    dom.smStatusIcon = document.getElementById('sm-status-icon');
    dom.smStatusText = document.getElementById('sm-status-text');
    dom.smProdCapsules = document.getElementById('sm-prod-capsules');
    dom.smEsgCompliance = document.getElementById('sm-esg-compliance');
    dom.smAutoRefusals = document.getElementById('sm-auto-refusals');
    dom.smEngineStatus = document.getElementById('sm-engine-status');
    dom.smExecCycles = document.getElementById('sm-exec-cycles');
    dom.smCurrentCapsule = document.getElementById('sm-current-capsule');
    dom.smProcEfficiencyValue = document.getElementById('sm-proc-efficiency-value');
    dom.smProcEfficiencyBar = document.getElementById('sm-proc-efficiency-bar');
    dom.smPauseExecutionBtn = document.getElementById('sm-pause-execution-btn');
    dom.smPauseBtnIcon = document.getElementById('sm-pause-btn-icon') as unknown as SVGElement | null;
    dom.smPauseBtnText = document.getElementById('sm-pause-btn-text');
    dom.smDecisionLog = document.getElementById('sm-decision-log');
    dom.smPipelineTabs = document.querySelectorAll('#sm-pipeline-tabs .sm-tab-button');
    dom.smPipelineTabContentPanes = document.querySelectorAll('#sm-pipeline-tab-content .sm-tab-pane');
    dom.smCapsuleInspectorContent = document.getElementById('sm-capsule-inspector-content');
    dom.smFloatingChatBtn = document.getElementById('sm-floating-chat-btn');
    const stageIds = ['raw', 'mfg', 'qc', 'pkg'];
    stageIds.forEach(id => {
        const capitalizedId = capitalizeFirstLetter(id);
        dom[`smPipeline${capitalizedId}Status`] = document.getElementById(`sm-pipeline-${id}-status`);
        dom[`smPipeline${capitalizedId}Progress`] = document.getElementById(`sm-pipeline-${id}-progress`);
        dom[`smPipeline${capitalizedId}ProgressVal`] = document.getElementById(`sm-pipeline-${id}-progress-val`);
        dom[`smPipeline${capitalizedId}Capsules`] = document.getElementById(`sm-pipeline-${id}-capsules`);
    });
    dom.smProdMetricsTons = document.getElementById('sm-prod-metrics-tons');
    dom.smProdMetricsEsgRate = document.getElementById('sm-prod-metrics-esg-rate');
    dom.smEfficiencyTime = document.getElementById('sm-efficiency-time');
    dom.smEfficiencyUptime = document.getElementById('sm-efficiency-uptime');
    dom.smQualityRefusalsBatches = document.getElementById('sm-quality-refusals-batches');
    dom.smQualityRefusalsRate = document.getElementById('sm-quality-refusals-rate');


    dom.capsuleUploaderView = document.getElementById('capsule-uploader-view') as HTMLElement;
    dom.capsuleFileInput = document.getElementById('capsule-file-input') as HTMLInputElement;
    dom.browseFilesButton = document.getElementById('browse-files-button');
    dom.fileNameDisplay = document.getElementById('file-name-display');
    dom.fileUploaderSection = document.getElementById('file-uploader-section');
    dom.capsulePreviewModal = document.getElementById('capsule-preview-modal');
    dom.jsonPreviewContent = document.getElementById('json-preview-content');
    dom.cancelUploadButton = document.getElementById('cancel-upload-button') as HTMLButtonElement;
    dom.confirmUploadButton = document.getElementById('confirm-upload-button') as HTMLButtonElement;

    dom.monitorView = document.getElementById('monitor-view') as HTMLElement;
    dom.monitorFilterTenant = document.getElementById('monitor-filter-tenant') as HTMLInputElement;
    dom.monitorFilterDate = document.getElementById('monitor-filter-date') as HTMLInputElement;
    dom.monitorFilterStatus = document.getElementById('monitor-filter-status') as HTMLSelectElement;
    dom.monitorCapsuleTable = document.getElementById('monitor-capsule-table') as HTMLElement;
    dom.monitorDetailsPane = document.getElementById('monitor-details-pane');
    dom.monitorSelectedCapsuleInfo = document.getElementById('monitor-selected-capsule-info');
    dom.esgChartCanvas = document.getElementById('esg-chart') as HTMLCanvasElement;
    dom.esgQualitativeInfo = document.getElementById('esg-qualitative-info');
    dom.monitorRefusalLogPane = document.getElementById('monitor-refusal-log-pane');
    dom.refusalLogDisplay = document.getElementById('refusal-log-display');

    dom.apiCredentialsView = document.getElementById('api-credentials-view') as HTMLElement;
    dom.createApiKeyBtn = document.getElementById('create-api-key-btn') as HTMLButtonElement;
    dom.apiKeysTableBody = document.getElementById('api-keys-table-body') as HTMLElement;
    dom.coreApiEndpointsContainer = document.getElementById('core-api-endpoints-container');
    dom.createApiKeyModal = document.getElementById('create-api-key-modal') as HTMLElement;
    dom.closeCreateApiKeyModalBtn = document.getElementById('close-create-api-key-modal-btn');
    dom.createApiKeyForm = document.getElementById('create-api-key-form') as HTMLFormElement;
    dom.apiKeyNameInput = document.getElementById('api-key-name-input') as HTMLInputElement;
    dom.newApiKeyDisplayArea = document.getElementById('new-api-key-display-area');
    dom.newApiKeyValue = document.getElementById('new-api-key-value');
    dom.copyNewApiKeyBtn = document.getElementById('copy-new-api-key-btn') as HTMLButtonElement;
    dom.cancelCreateApiKeyBtn = document.getElementById('cancel-create-api-key-btn') as HTMLButtonElement;
    dom.submitCreateApiKeyBtn = document.getElementById('submit-create-api-key-btn') as HTMLButtonElement;
    dom.doneCreateApiKeyBtn = document.getElementById('done-create-api-key-btn') as HTMLButtonElement;

    dom.integrationsView = document.getElementById('integrations-view') as HTMLElement;
    dom.integrationsAccordionHeaders = document.querySelectorAll('#integrations-accordion .accordion-header');

    dom.aiCompanionView = document.getElementById('ai-companion-view') as HTMLElement;
    dom.chatHistoryElement = document.getElementById('chat-history');
    dom.chatInputElement = document.getElementById('chat-input') as HTMLInputElement;
    dom.chatSendButton = document.getElementById('chat-send-button') as HTMLButtonElement;

    dom.studentProgramView = document.getElementById('student-program-view') as HTMLElement;
    dom.studentApplicationForm = document.getElementById('student-application-form') as HTMLFormElement;

    dom.supportView = document.getElementById('support-view') as HTMLElement;
    dom.supportAccordionHeaders = document.querySelectorAll('#support-accordion .accordion-header');
    dom.contactSupportForm = document.getElementById('contact-support-form') as HTMLFormElement;

    dom.legalView = document.getElementById('legal-view') as HTMLElement;

    dom.settingsView = document.getElementById('settings-view') as HTMLElement;
    dom.userProfileForm = document.getElementById('user-profile-form') as HTMLFormElement;
    dom.passwordChangeForm = document.getElementById('password-change-form') as HTMLFormElement;
    dom.apiKeysForm = document.getElementById('api-keys-form') as HTMLFormElement; 
    dom.profileNameInput = document.getElementById('profile-name') as HTMLInputElement;
    dom.profileEmailInput = document.getElementById('profile-email') as HTMLInputElement;
    dom.settingsSupabaseKeyInput = document.getElementById('settings-supabase-key') as HTMLInputElement;
    dom.settingsFirebaseTokenInput = document.getElementById('settings-firebase-token') as HTMLInputElement;
}

function initApp() {
    queryDomElements();
    initializeGemini(); 
    initEventListeners();
    
    const initialView = window.location.hash ? window.location.hash.substring(1) : 'home';
    const validViews = Array.from(dom.views).map(v => v.id.replace('-view', ''));
    if (validViews.includes(initialView)) {
        switchView(initialView);
    } else {
        switchView('home');
    }
    
    if (!appData.currentUser) {
         appData.currentUser = { name: "Richard Wijaya", email: "developer@clydealpha.com", role: 'Developer' };
    }
    renderSettingsView(); 
}

document.addEventListener('DOMContentLoaded', initApp);

window.addEventListener('hashchange', () => {
    const hashView = window.location.hash.substring(1);
    const validViews = Array.from(dom.views).map(v => v.id.replace('-view', ''));
    if (hashView && validViews.includes(hashView) && hashView !== appData.currentView) {
        switchView(hashView);
    } else if (!hashView && appData.currentView !== 'home') { // If hash is empty, go to home
        switchView('home');
    }
});

// Ensure a view is active on load if no hash or invalid hash
if (!window.location.hash || !Array.from(dom.views).map(v => v.id.replace('-view', '')).includes(window.location.hash.substring(1))) {
    if (appData.currentView !== 'home') { // check if initApp already set a view
         // switchView('home'); // Redundant if initApp handles default
    }
}
